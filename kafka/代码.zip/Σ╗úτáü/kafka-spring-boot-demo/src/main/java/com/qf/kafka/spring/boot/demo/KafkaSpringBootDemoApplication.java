package com.qf.kafka.spring.boot.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaSpringBootDemoApplication {

  public static void main(String[] args) {
    SpringApplication.run(KafkaSpringBootDemoApplication.class, args);
  }

}
