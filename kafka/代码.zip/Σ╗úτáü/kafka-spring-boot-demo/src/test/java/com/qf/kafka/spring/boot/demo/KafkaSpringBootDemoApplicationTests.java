package com.qf.kafka.spring.boot.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSpringBootDemoApplicationTests {

  @Test
  void contextLoads() {
  }

}
